#ifndef SIMPLE_H
#define SIMPLE_H


class Simple
{
public:
    Simple();
    int add(int i) {return i+1; };
    int addError(int i){return i;};
};

#endif // SIMPLE_H
