#include "simple.h"

Simple::Simple()
{

}
